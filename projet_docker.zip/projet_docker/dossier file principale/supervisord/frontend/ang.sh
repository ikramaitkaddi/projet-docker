#!/bin/bash

cd angular-10-client
exec ng serve --host 0.0.0.0