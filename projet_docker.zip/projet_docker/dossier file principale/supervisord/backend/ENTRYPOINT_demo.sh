#!/bin/bash
java -jar target/demo_2.jar