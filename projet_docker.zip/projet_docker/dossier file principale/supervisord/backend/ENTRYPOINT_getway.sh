#!/bin/bash
java -jar target/cloud-getway.jar