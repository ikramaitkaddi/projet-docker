#!/bin/bash
java -jar target/eureka-server.jar