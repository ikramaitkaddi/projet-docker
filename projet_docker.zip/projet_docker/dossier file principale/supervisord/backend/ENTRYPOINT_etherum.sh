#!/bin/bash
java -jar target/demo-etherum.jar